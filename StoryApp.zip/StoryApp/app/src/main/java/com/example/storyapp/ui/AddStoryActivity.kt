package com.example.storyapp.ui

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.view.MenuItem
import android.view.View
import android.widget.ProgressBar
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Observer
import com.bumptech.glide.Glide
import com.example.storyapp.R
import com.example.storyapp.data.ResultState
import com.example.storyapp.data.injection.Injection
import com.example.storyapp.data.local.getImageUri
import com.example.storyapp.databinding.ActivityAddStoryBinding
import com.example.storyapp.viewmodel.AddStoryViewModel
import com.example.storyapp.viewmodel.ViewModelFactory

class AddStoryActivity : AppCompatActivity() {

    private lateinit var binding: ActivityAddStoryBinding
    private lateinit var currentPhotoUri: Uri
    private val addStoryViewModel: AddStoryViewModel by viewModels {
        ViewModelFactory(storyRepository = Injection.provideStoryRepository(this))
    }
    private lateinit var progressBar: ProgressBar

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAddStoryBinding.inflate(layoutInflater)
        setContentView(binding.root)

        progressBar = findViewById(R.id.progressBar)

        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = getString(R.string.upload_button)

        binding.btnCamera.setOnClickListener { startCamera() }
        binding.btnGallery.setOnClickListener { openGallery() }
        binding.btnUpload.setOnClickListener { uploadStory() }

        observeViewModel()
    }

    private fun observeViewModel() {
        addStoryViewModel.addStoryResult.observe(this, Observer { result ->
            when (result) {
                is ResultState.Success -> {
                    Toast.makeText(this, "Story uploaded successfully!", Toast.LENGTH_SHORT).show()
                    val intent = Intent(this, MainActivity::class.java)
                    intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK
                    intent.putExtra("refresh", true)
                    startActivity(intent)
                }

                is ResultState.Error -> {
                    Toast.makeText(this, "Upload failed: ${result.error}", Toast.LENGTH_SHORT)
                        .show()
                    progressBar.visibility = View.GONE
                }

                is ResultState.Loading -> {
                    progressBar.visibility = View.VISIBLE
                }
            }
        })
    }

    private fun startCamera() {
        currentPhotoUri = getImageUri(this)
        launcherIntentCamera.launch(currentPhotoUri)
    }

    private val launcherIntentCamera = registerForActivityResult(
        ActivityResultContracts.TakePicture()
    ) { isSuccess ->
        if (isSuccess) {
            Glide.with(this).load(currentPhotoUri).into(binding.ivPreview)
        }
    }

    private fun openGallery() {
        val intent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
        startActivityForResult(intent, REQUEST_GALLERY)
    }

    private fun uploadStory() {
        val description = binding.etDescription.text.toString()
        if (description.isEmpty()) {
            binding.etDescription.error = getString(R.string.story_description)
            return
        }
        addStoryViewModel.uploadStory(currentPhotoUri, description)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_GALLERY && resultCode == Activity.RESULT_OK) {
            data?.data?.let { selectedImageUri ->
                currentPhotoUri = selectedImageUri
                Glide.with(this).load(currentPhotoUri).into(binding.ivPreview)
            }
        }
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            android.R.id.home -> {
                finish()
                true
            }

            else -> super.onOptionsItemSelected(item)
        }
    }

    companion object {
        private const val REQUEST_GALLERY = 2
    }
}
