package com.example.storyapp.ui.fragment

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.storyapp.adapter.MyStoriesRecyclerViewAdapter
import com.example.storyapp.data.injection.Injection
import com.example.storyapp.databinding.FragmentDiscoverBinding
import com.example.storyapp.ui.StoryDetailActivity
import com.example.storyapp.viewmodel.DiscoverViewModel
import com.example.storyapp.viewmodel.ViewModelFactory

class DiscoverFragment : Fragment() {

    private lateinit var binding: FragmentDiscoverBinding
    private lateinit var storyAdapter: MyStoriesRecyclerViewAdapter
    private lateinit var discoverViewModel: DiscoverViewModel

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentDiscoverBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val refresh = arguments?.getBoolean("refresh") ?: false
        setupRecyclerView()
        setupViewModel()
        setupObservers()

        if (refresh) {
            discoverViewModel.getStories()
        }
    }

    private fun setupRecyclerView() {
        storyAdapter = MyStoriesRecyclerViewAdapter { story ->
            val intent = Intent(requireContext(), StoryDetailActivity::class.java)
            intent.putExtra("story", story)
            startActivity(intent)
        }
        binding.list.layoutManager = LinearLayoutManager(requireContext())
        binding.list.adapter = storyAdapter
    }

    private fun setupViewModel() {
        val storyRepository = Injection.provideStoryRepository(requireContext())
        discoverViewModel =
            ViewModelProvider(this, ViewModelFactory(storyRepository = storyRepository)).get(
                DiscoverViewModel::class.java
            )

        discoverViewModel.getStories()
    }

    private fun setupObservers() {
        discoverViewModel.storiesResult.observe(viewLifecycleOwner, Observer { result ->
            result.onSuccess { storyResponse ->
                Log.d("DiscoverFragment", "Stories fetched successfully")
                storyAdapter.submitList(storyResponse.listStory)
            }
            result.onFailure { exception ->
                Log.e("DiscoverFragment", "Failed to fetch stories: ${exception.message}")
            }
        })

        discoverViewModel.loading.observe(viewLifecycleOwner, Observer { isLoading ->
            binding.progressBar.visibility = if (isLoading) View.VISIBLE else View.GONE
        })

        discoverViewModel.error.observe(viewLifecycleOwner, Observer { errorMessage ->
            binding.errorText.visibility = if (errorMessage != null) View.VISIBLE else View.GONE
            binding.errorText.text = errorMessage
        })

        discoverViewModel.empty.observe(viewLifecycleOwner, Observer { isEmpty ->
            binding.emptyText.visibility = if (isEmpty) View.VISIBLE else View.GONE
        })
    }

    companion object {
        @JvmStatic
        fun newInstance(refresh: Boolean) = DiscoverFragment().apply {
            arguments = Bundle().apply {
                putBoolean("refresh", refresh)
            }
        }
    }
}
