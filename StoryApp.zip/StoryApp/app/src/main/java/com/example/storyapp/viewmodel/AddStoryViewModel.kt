package com.example.storyapp.viewmodel

import android.net.Uri
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.storyapp.data.ResultState
import com.example.storyapp.data.model.StoryResponse
import com.example.storyapp.data.repository.StoryRepository
import kotlinx.coroutines.launch

class AddStoryViewModel(private val storyRepository: StoryRepository) : ViewModel() {

    private val _addStoryResult = MutableLiveData<ResultState<StoryResponse>>()
    val addStoryResult: LiveData<ResultState<StoryResponse>> = _addStoryResult

    private val _loading = MutableLiveData<Boolean>()
    val loading: LiveData<Boolean> get() = _loading

    fun uploadStory(photoUri: Uri, description: String) {
        viewModelScope.launch {
            _loading.value = true
            val result = storyRepository.uploadStory(photoUri, description)
            _addStoryResult.value = result
            _loading.value = false
        }
    }
}
