package com.example.storyapp.ui

import android.os.Bundle
import android.view.MenuItem
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.lifecycle.ViewModelProvider
import com.bumptech.glide.Glide
import com.example.storyapp.R
import com.example.storyapp.data.injection.Injection
import com.example.storyapp.data.model.ListStoryItem
import com.example.storyapp.databinding.ActivityStoryDetailBinding
import com.example.storyapp.viewmodel.StoryDetailViewModel
import com.example.storyapp.viewmodel.ViewModelFactory

class StoryDetailActivity : AppCompatActivity() {

    private lateinit var storyDetailViewModel: StoryDetailViewModel
    private lateinit var binding: ActivityStoryDetailBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityStoryDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val toolbar: Toolbar = binding.toolbar
        setSupportActionBar(toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = getString(R.string.detail)

        val story = intent.getParcelableExtra<ListStoryItem>("story")

        story?.let {
            binding.tvName.text = it.name
            binding.tvDescription.text = it.description
            Glide.with(this).load(it.photoUrl).into(binding.ivPhoto)
        }

        val storyRepository = Injection.provideStoryRepository(this)
        storyDetailViewModel =
            ViewModelProvider(this, ViewModelFactory(storyRepository = storyRepository)).get(
                StoryDetailViewModel::class.java
            )

        story?.id?.let { storyDetailViewModel.fetchStoryDetail(it) }
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            android.R.id.home -> {
                finishAfterTransition()
                true
            }

            else -> super.onOptionsItemSelected(item)
        }
    }
}
