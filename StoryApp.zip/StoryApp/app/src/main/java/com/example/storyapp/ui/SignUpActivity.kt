package com.example.storyapp.ui

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Observer
import com.example.storyapp.R
import com.example.storyapp.data.ResultState
import com.example.storyapp.data.injection.Injection
import com.example.storyapp.databinding.ActivitySignupBinding
import com.example.storyapp.viewmodel.RegisterViewModel
import com.example.storyapp.viewmodel.ViewModelFactory

class SignUpActivity : AppCompatActivity() {

    private val userRepository by lazy { Injection.provideUserRepository(this) }
    private val registerViewModel: RegisterViewModel by viewModels {
        ViewModelFactory(userRepository = userRepository)
    }
    private lateinit var binding: ActivitySignupBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySignupBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.registerButton.setOnClickListener {
            val name = binding.edRegisterName.text.toString()
            val email = binding.edRegisterEmail.text.toString()
            val password = binding.edRegisterPassword.text.toString()

            if (name.isEmpty() || email.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, getString(R.string.empty_field_error), Toast.LENGTH_SHORT).show()
            } else if (password.length < 8) {
                binding.edRegisterPassword.error = getString(R.string.password_length_error)
            } else {
                registerViewModel.submitRegister(name, email, password)
            }
        }

        registerViewModel.responseResult.observe(this, Observer { result ->
            when (result) {
                is ResultState.Success -> {
                    Toast.makeText(this, getString(R.string.registration_successful), Toast.LENGTH_SHORT).show()
                    navigateToLogin()
                    binding.progressBar.visibility = View.GONE
                }
                is ResultState.Error -> {
                    Toast.makeText(this, "${getString(R.string.registration_failed)}: ${result.error}", Toast.LENGTH_SHORT).show()
                    binding.progressBar.visibility = View.GONE
                }
                is ResultState.Loading -> {
                    binding.progressBar.visibility = View.VISIBLE
                }
            }
        })

        binding.hyperlinkLogin.setOnClickListener {
            startActivity(Intent(this, LoginActivity::class.java))
        }
    }

    private fun navigateToLogin() {
        val intent = Intent(this, LoginActivity::class.java)
        startActivity(intent)
        finish()
    }
}
