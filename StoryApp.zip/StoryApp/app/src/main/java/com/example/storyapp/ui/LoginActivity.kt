package com.example.storyapp.ui

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Observer
import androidx.lifecycle.lifecycleScope
import com.example.storyapp.R
import com.example.storyapp.data.ResultState
import com.example.storyapp.data.injection.Injection
import com.example.storyapp.data.local.UserPreference
import com.example.storyapp.data.local.dataStore
import com.example.storyapp.databinding.ActivityLoginBinding
import com.example.storyapp.viewmodel.LoginViewModel
import com.example.storyapp.viewmodel.ViewModelFactory
import kotlinx.coroutines.launch

class LoginActivity : AppCompatActivity() {

    private val userRepository by lazy { Injection.provideUserRepository(this) }
    private val loginViewModel: LoginViewModel by viewModels {
        ViewModelFactory(userRepository = userRepository)
    }

    private val userPreference by lazy { UserPreference.getInstance(dataStore) }
    private lateinit var binding: ActivityLoginBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.loginButton.setOnClickListener {
            val email = binding.edLoginEmail.text.toString()
            val password = binding.edLoginPassword.text.toString()

            if (email.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, R.string.empty_field_error, Toast.LENGTH_SHORT).show()
            } else if (password.length < 8) {
                binding.edLoginPassword.error = getString(R.string.password_length_error)
            } else {
                loginViewModel.submitLogin(email, password)
            }
        }

        loginViewModel.responseResult.observe(this, Observer { result ->
            when (result) {
                is ResultState.Success -> {
                    lifecycleScope.launch {
                        val token = result.data.loginResult?.token ?: ""
                        userPreference.saveUserToken(token)
                        navigateToMain()
                    }
                }
                is ResultState.Error -> {
                    Toast.makeText(this, getString(R.string.login_failed, result.error), Toast.LENGTH_SHORT).show()
                }
                is ResultState.Loading -> {
                    binding.progressBar.visibility = View.VISIBLE
                }
            }
        })

        loginViewModel.loading.observe(this, Observer { isLoading ->
            binding.progressBar.visibility = if (isLoading) View.VISIBLE else View.GONE
        })

        binding.hyperlinkRegister.setOnClickListener {
            startActivity(Intent(this, SignUpActivity::class.java))
        }
    }

    private fun navigateToMain() {
        val intent = Intent(this, MainActivity::class.java)
        startActivity(intent)
        finish()
    }
}
