package com.example.storyapp.data.repository

import android.content.ContentResolver
import android.net.Uri
import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.example.storyapp.data.ResultState
import com.example.storyapp.data.local.UserPreference
import com.example.storyapp.data.model.ListStoryItem
import com.example.storyapp.data.model.StoryResponse
import com.example.storyapp.data.network.ApiService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.RequestBody.Companion.asRequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import retrofit2.HttpException
import java.io.File
import java.io.FileOutputStream

class StoryRepository private constructor(
    private val apiService: ApiService,
    private val userPreference: UserPreference,
    private val contentResolver: ContentResolver
) {
    private val _storiesResult = MutableLiveData<Result<StoryResponse>>()
    val storiesResult: LiveData<Result<StoryResponse>> = _storiesResult

    suspend fun getStories() {
        val token = userPreference.getUserToken().first()
        if (token != null) {
            Log.d("StoryRepository", "Fetching stories with token: $token")
            withContext(Dispatchers.IO) {
                try {
                    val response = apiService.getStories()
                    Log.d("StoryRepository", "Stories fetched: ${response.listStory.size} items")
                    _storiesResult.postValue(Result.success(response))
                } catch (e: HttpException) {
                    Log.e("StoryRepository", "HttpException: ${e.message()}")
                    _storiesResult.postValue(Result.failure(e))
                } catch (e: Exception) {
                    Log.e("StoryRepository", "Exception: ${e.message}")
                    _storiesResult.postValue(Result.failure(e))
                }
            }
        } else {
            Log.e("StoryRepository", "Token is null")
        }
    }

    suspend fun uploadStory(photoUri: Uri, description: String): ResultState<StoryResponse> {
        return withContext(Dispatchers.IO) {
            try {
                val token = userPreference.getUserToken().first()
                    ?: return@withContext ResultState.Error("Token is null")
                val file = uriToFile(photoUri)
                val requestImageFile = file.asRequestBody("image/jpeg".toMediaTypeOrNull())
                val imageMultipart: MultipartBody.Part = MultipartBody.Part.createFormData(
                    "photo", file.name, requestImageFile
                )
                val descriptionRequestBody =
                    description.toRequestBody("text/plain".toMediaTypeOrNull())

                val response = apiService.uploadStory(imageMultipart, descriptionRequestBody)
                ResultState.Success(response)
            } catch (e: Exception) {
                Log.e("StoryRepository", "uploadStory Exception: ${e.message}")
                ResultState.Error(e.message ?: "Unknown error")
            }
        }
    }

    private fun uriToFile(uri: Uri): File {
        val inputStream = contentResolver.openInputStream(uri)
        val file = File.createTempFile("image", ".jpg")
        val outputStream = FileOutputStream(file)
        inputStream?.use { input ->
            outputStream.use { output ->
                input.copyTo(output)
            }
        }
        return file
    }

    suspend fun getStoryDetail(storyId: String): Result<ListStoryItem> {
        return withContext(Dispatchers.IO) {
            try {
                val response = apiService.getStoryDetail(storyId)
                Result.success(response)
            } catch (e: Exception) {
                Result.failure(e)
            }
        }
    }

    companion object {
        @Volatile
        private var instance: StoryRepository? = null

        fun getInstance(
            apiService: ApiService,
            userPreference: UserPreference,
            contentResolver: ContentResolver
        ): StoryRepository =
            instance ?: synchronized(this) {
                instance ?: StoryRepository(
                    apiService,
                    userPreference,
                    contentResolver
                ).also { instance = it }
            }
    }
}
