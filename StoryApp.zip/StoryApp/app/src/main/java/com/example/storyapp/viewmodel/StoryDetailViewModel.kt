package com.example.storyapp.viewmodel

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.storyapp.data.model.ListStoryItem
import com.example.storyapp.data.repository.StoryRepository
import kotlinx.coroutines.launch

class StoryDetailViewModel(private val storyRepository: StoryRepository) : ViewModel() {


    private val _storyDetail = MutableLiveData<ListStoryItem>()
    val storyDetail: LiveData<ListStoryItem> = _storyDetail

    private val _isLoading = MutableLiveData<Boolean>()
    val isLoading: LiveData<Boolean> = _isLoading

    private val _error = MutableLiveData<String>()
    val error: LiveData<String> = _error

    fun fetchStoryDetail(storyId: String) {
        viewModelScope.launch {
            _isLoading.value = true
            val result = storyRepository.getStoryDetail(storyId)
            result.onSuccess { story ->
                _isLoading.value = false
                _storyDetail.value = story
            }
            result.onFailure { exception ->
                _isLoading.value = false
                _error.value = exception.message ?: "Unknown error"
            }
        }
    }
}
