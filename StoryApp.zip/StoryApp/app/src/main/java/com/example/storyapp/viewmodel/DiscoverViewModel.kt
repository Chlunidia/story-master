package com.example.storyapp.viewmodel

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.storyapp.data.model.StoryResponse
import com.example.storyapp.data.repository.StoryRepository
import kotlinx.coroutines.launch

class DiscoverViewModel(
    private val storyRepository: StoryRepository
) : ViewModel() {

    val storiesResult: LiveData<Result<StoryResponse>> = storyRepository.storiesResult
    private val _loading = MutableLiveData<Boolean>()
    val loading: LiveData<Boolean> get() = _loading
    private val _error = MutableLiveData<String?>()
    val error: LiveData<String?> get() = _error
    private val _empty = MutableLiveData<Boolean>()
    val empty: LiveData<Boolean> get() = _empty

    fun getStories() {
        Log.d("DiscoverViewModel", "Fetching stories")
        viewModelScope.launch {
            _loading.value = true
            try {
                storyRepository.getStories()
                _empty.value = storyRepository.storiesResult.value?.getOrNull()?.listStory.isNullOrEmpty()
            } catch (e: Exception) {
                _error.value = e.message
            } finally {
                _loading.value = false
            }
        }
    }
}
